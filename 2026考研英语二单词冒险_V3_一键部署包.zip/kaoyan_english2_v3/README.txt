2026考研英语二·单词冒险 V3

这是可直接部署到静态网站托管平台的版本，入口文件已经命名为 index.html。

最快部署方式：Netlify Drop
1. 打开 https://app.netlify.com/drop
2. 登录 Netlify。
3. 将这个文件夹里的 index.html 所在文件夹上传/拖入部署区域。
4. 发布完成后会得到一个 netlify.app 网站地址。

GitHub Pages：
1. 新建 GitHub 仓库。
2. 上传 index.html 到仓库根目录。
3. 在 Settings > Pages 中选择部署来源。
4. 发布后即可通过 github.io 地址访问。

注意：这是纯前端静态网站，恋人聊天目前是本地脚本式虚拟恋人，不会调用外部 AI API，也不会暴露 API Key。
